/*
	The file operationsinterface_getvernissageversion.cpp is part of the "MatrixFileReader XOP".
	It is licensed under the LGPLv3 with additional permissions,
	see License.txt	in the source folder for details.
*/

#include "header.h"

#include "operationstructs.h"
#include "operationsinterface.h"

#include "globaldata.h"

extern "C" int ExecuteGetVernissageVersion(GetVernissageVersionRuntimeParamsPtr p){
	BEGIN_OUTER_CATCH
	SetOperationNumVar(V_DLLversion,0);

	Vernissage::Session *pSession = globDataPtr->getVernissageSession();
	ASSERT_RETURN_ZERO(pSession);

	SetOperationNumVar(V_DLLversion,stringToAnyType<double>(globDataPtr->getVernissageVersion()));
	END_OUTER_CATCH
	return 0;
}
