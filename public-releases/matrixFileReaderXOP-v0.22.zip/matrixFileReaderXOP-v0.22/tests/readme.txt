The unit and regression test suite requires the UTF from [1] and always
completes without error.
The reference data is available upon request as it is roughly 5GB.

[1]: http://www.igorexchange.com/project/unitTesting

