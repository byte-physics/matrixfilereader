#pragma once

const char GIT_VERSION[] = "88334ad";
