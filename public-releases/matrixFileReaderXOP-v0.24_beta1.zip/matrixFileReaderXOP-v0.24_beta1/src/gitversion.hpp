#pragma once

const char GIT_VERSION[] = "c7cc13f";
