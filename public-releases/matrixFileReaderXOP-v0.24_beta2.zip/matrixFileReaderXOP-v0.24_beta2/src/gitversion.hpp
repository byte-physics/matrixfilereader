#pragma once

const char GIT_VERSION[] = "19bca9d";
