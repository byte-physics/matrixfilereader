#pragma once

const char GIT_VERSION[] = "d041993";
