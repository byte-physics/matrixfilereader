#pragma once

const char GIT_VERSION[] = "b3c50f6";
