#pragma once

const char GIT_VERSION[] = "b756252";
