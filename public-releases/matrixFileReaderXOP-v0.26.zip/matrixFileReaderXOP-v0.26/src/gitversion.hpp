#pragma once

const char GIT_VERSION[] = "0793632";
