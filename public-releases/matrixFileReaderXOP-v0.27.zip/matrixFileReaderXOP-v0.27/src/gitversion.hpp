#pragma once

const char GIT_VERSION[] = "8ad2e36";
